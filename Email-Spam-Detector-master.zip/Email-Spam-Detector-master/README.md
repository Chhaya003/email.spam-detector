# Spam-email-Detection
College project to detect spam mails


Modules used are:-


Streamlit -------  (Streamlit is an open-source Python library that makes it easy to create and share beautiful, custom web apps for machine learning and data science)



Pickle -----  (Pickle in Python is primarily used in serializing and deserializing a Python object structure. In other words, it's the process of converting a Python object into a byte stream to store it in a file/database, maintain program state across sessions, or transport data over the network.)


String ------(string module contains a single utility function - capwords(s, sep=None). This function split the specified string into words using str. split(). Then it capitalizes each word using str)


nltk-----( Natural Language Toolkit, is a Python package that you can use for NLP. A lot of the data that you could be analyzing is unstructured data and contains human-readable text. Before you can analyze that data programmatically, you first need to preprocess it.)


To Run the program use this :- streamlit run app.py in the terminal.
